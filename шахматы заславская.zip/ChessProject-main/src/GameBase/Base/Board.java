package GameBase.Base;

public class Board {
     static protected Movable[][] field;

}