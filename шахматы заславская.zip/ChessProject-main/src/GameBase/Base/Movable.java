package GameBase.Base;

public interface Movable {
    boolean canMove(Coordinate to);
}
